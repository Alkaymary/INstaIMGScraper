﻿Imports System.Net
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Threading
Public Class Form1
    ' INstagram UserName Post [IMG] Scraper 
    'Don't Copy , Should U Learn It How To Work It
    'Aslaam Alkaymary </>
    'Instagram:https://instagram.com/ak.coder  ||  Tgelegram:https://t.me.com/ko_tools  || GitHub: https://github.com/Alkaymary
#Region "Tool's Code"
    Dim picopy As Image : Dim listLink As New TextBox, countlist As Integer = 0 : Dim PPath As String
    Public Function Random() As String
        Dim text As String = "abcdefjhigklmnopqrstuvwxyz1234567890"
        Dim stringBuilder As StringBuilder = New StringBuilder()
        Dim random1 As Random = New Random()
        Dim num As Integer = 1
        Do
            Dim index As Integer = random1.[Next](0, text.Length)
            Dim value As Char = text(index)
            stringBuilder.Append(value)
            num += 1
        Loop While num <= 12
        Return stringBuilder.ToString() + "_Ak.jpg"
    End Function
    Sub GetPostCode(ByVal UserName As String)
        Try
            Dim Respone As String = New WebClient().DownloadString("https://www.instagram.com/" + UserName.Replace("@", "") + "/?__a=1")
            Dim MC1 As MatchCollection = Regex.Matches(Respone, """display_url"":""(.*?)"",")
            Dim EC1 As IEnumerator = MC1.GetEnumerator() '
            While EC1.MoveNext()
                listLink.Text += Regex.Match(CType(EC1.Current, Match).ToString(), """display_url"":""(.*?)"",").Groups(1).Value + vbCrLf
            End While
            If listLink.Lines.Length = 0 Then
                MsgBox("Error - Please Checking UserName Firstly And Try Again :)", vbCritical, "UserName Not Found Or UserName Is Private") : Exit Sub
            Else
                Dim ThreadsPic As New Thread(Sub()
                                                 For i = 0 To listLink.Lines.Count - 1
                                                     PictureBox1.ImageLocation = listLink.Lines(i)
                                                     Thread.Sleep(6000)
                                                     picopy = PictureBox1.Image
                                                     PPath = CurDir() & "\" & Random()
                                                     picopy.Save(PPath) : Label3.Text = PPath

                                                 Next
                                                 MsgBox("DoNe All New Pic Was Grabed", vbInformation, "Scrap Finished")
                                             End Sub)
                ThreadsPic.Start()
            End If
        Catch ex As WebException
            MsgBox("Error Message !" + vbCrLf + vbCrLf + ex.Message)
        End Try
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim ThreadsPic As New Thread(Sub()
                                         GetPostCode(TextBox1.Text)
                                     End Sub)
        ThreadsPic.Start()
    End Sub
    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Control.CheckForIllegalCrossThreadCalls = False
    End Sub
#End Region
End Class